import{a as t}from"../chunks/entry.vewctW4l.js";export{t as start};
