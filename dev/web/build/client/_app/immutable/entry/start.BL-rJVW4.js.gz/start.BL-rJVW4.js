import{a as t}from"../chunks/entry.BVwUrbZ_.js";export{t as start};
